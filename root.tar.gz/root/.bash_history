history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
nano /etc/hosts
vim /etc/hosts
hostname
logout
clear
apt update
apt install apache2 php libapache2-mod-php
systemctl status apache2
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html && cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html
rm /var/www/html/index.html
chown -R www-data:www-data /var/www/html/ chmod -R 755 /var/www/html/
chown -R www-data:www-data /var/www/html/ && chmod -R 755 /var/www/html/
clear
apt install mariadb-server
systemctl status mariadb
mariadb < /root/Material_Adicional_TPVMCA/db.sql
apt install php-mysql
systemctl restart apache2
ip a
clear
nano /etc/network/interfaces
vim /etc/network/interfaces
ip a
vim /etc/network/interfaces
systemctl restart networking
logout
cat /etc/debian-version
debian
clear
cat /etc/debian_version
apt update && apt upgrade && apt full-upgrade
vim /etc/apt/sources.list
ls /etc/apt/sources.list.d/
apt update && apt upgrade
cat /etc/debian_version
clear
cat /etc/debian_version
apt install openssh-server
systemctl status ssh
ls /root
vim /etc/ssh/sshd_config
systemctl restar ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
tar -xzf Material_Adicional_TPVMCA.tar.gz
cat /root/Material_Adicional_TPVMCA
ls /root/Material_Adicional_TPVMCA
clear
ls /root/Material_Adicional_TPVMCA
ls
cd Material_Adicional_TPVMCA
cat clave_publica.pub >> /root/.ssh/authorized_keys
cat clave_privada.txt
clear
python3 -m http server 8000
python3 -m http.server 8000
ip -a
ip
ipconfig
ip a
python3 -m http.server 8000
logout
ip a
reboot
shutdown
shutdown -c
lsblk
lsblk
clear
fdisk /dev/sdc
clear
fdisk /dev/sdc
clear
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
fdisk -l /dev/sdc
fdisk /dev/sdc2
fdisk /dev/sdc
lsbk
lsblk
clear
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir -p /www_dir /backup_dir
mount /dev/sdc2 /backup_dir
df -h /www_dir /backup_dir
cp /var/www/html/index.php /www_dir && cp /var/www/html/logo.png /www_dir
chown -R www-data:www-data /www_dir/ && chmod -R 755 /www_dir/
vim /etc/apache2/sites-available/000-default.conf
clear
apache2ctl configtest
systemctl restart apache2
reboot
blkid /dev/sdc1
clear
blkid /dev/sdc1
cp /etc/fstab /etc/fstab.bak
vim /etc/fstab
vil /etc/fstab
vim /etc/fstab
vim /etc/fstab
vim /etc/fstab
vim /etc/fstab
blkid /dev/sdc2
mount -a
vim /etc/fstab
nano /etc/fstab
apt install nano
nano /etc/fstab
nano /etc/fstab
mount -a
systemctl daemon-reload
mount -a
nano  /etc/fstab
mount -a
clear
nano /etc/fstab
cat /proc/patitions > /opt/particion
cat /proc/partitions > /opt/particion
clear
mkdir /opt/scripts
touch /opt/scripts/backup_full.sh
chmod 755 /opt/scripts/backup_full.sh
nano backup_full.sh
clear
nano backup_full.sh
./backup_full.sh origen destino
./backup._full.sh
./backup_full.sh
chmod 755 /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh origen destino
cd /opt/scripts
./backup_full.sh origen destino
/opt/scripts/backup_full.sh /www_dir /opt
cd ..
ls
cd scripts
ls
ls
nano backup_full.sh
cat backup_full.sh
./backup_full.sh origen destino
./backup_full.sh /opt /scripts
cd ..
ls
.backup_full.sh /opt /scripts
./backup_full.sh /opt /scripts
cd scripts
./backup_full.sh /scripts /scripts
ls
mkdir prueba
.backup_full.sh /scripts /prueba
./backup_full.sh /scripts /prueba
nano backup_full.sh
chmod 755 /opt/scripts/backup_full.sh
./backup_full.sh origen destino
./backup_full.sh /opt/scripts /opt/scripts/prueba
ls
cd prueba
ls
tar -xvf scripts_bkp_20260615.tar.gz
crontab -e
crontab -l
crontab -e
clear
crontab -l
apt install git
shutdown
shutdown -c
ip a
