#!/bin/bash

# backup_full.sh - Script de backup para TP Computación Aplicada

show_help() {
    echo "Uso: backup_full.sh [-help] <origen> <destino>"
    echo ""
    echo "Argumentos:"
    echo "  origen     Directorio a respaldar (ej: /var/log, /www_dir)"
    echo "  destino    Directorio donde guardar el backup (ej: /backup_dir)"
    echo ""
    echo "Opciones:"
    echo "  -help      Muestra esta ayuda"
    echo ""
    echo "Ejemplo:"
    echo "  backup_full.sh /var/log /backup_dir"
    echo "  Genera: /backup_dir/log_bkp_YYYYMMDD.tar.gz"
}

# Detecta si el primer argumento es un comando de ayuda, muestra el texto de ayuda, sale exitosamente del programa
if [[ "$1" == "-help" || "$1" == "--help" || "$1" == "-h" ]]; then
    show_help
    exit 0
fi

# Si la cantidad de argumentos recibidos ($#) no es igual a 2 entonces muestra mensaje de error y sale con fallo
if [[ $# -ne 2 ]]; then
    echo "Error: se requieren exactamente 2 argumentos (origen y destino)."
    echo "Use: backup_full.sh -help"
    exit 1
fi

ORIGEN="$1" #Crea constante origen con el valor del primer argumento recibido
DESTINO="$2" #Crea constante destino con el valor del segundo argumento recibido
FECHA=$(date +%Y%m%d) #Genera la fecha del dia en formato ANSI y la guarda en una constante
NOMBRE_BASE=$(basename "$ORIGEN") # Guarda el ultimo tramo del path de origen recibido
ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz" #Arma el nombre definitivo del backup a crear
RUTA_COMPLETA="${DESTINO}/${ARCHIVO}" #Define la ruta donde se guardara el backup

# Validar que el origen exista y sea directorio
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: el origen '$ORIGEN' no existe o no es un directorio."
    exit 1
fi

# Validar que el destino exista y sea directorio
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: el destino '$DESTINO' no existe o no es un directorio."
    exit 1
fi

# Validar que el filesystem del origen esté montado/disponible
if ! findmnt --target "$ORIGEN" > /dev/null 2>&1; then
    echo "Error: el filesystem de origen '$ORIGEN' no está disponible o montado."
    exit 1
fi

# Validar que el filesystem del destino esté montado/disponible
if ! findmnt --target "$DESTINO" > /dev/null 2>&1; then
    echo "Error: el filesystem de destino '$DESTINO' no está disponible o montado."
    exit 1
fi

# Validar que el destino sea escribible
if [[ ! -w "$DESTINO" ]]; then
    echo "Error: no hay permisos de escritura en '$DESTINO'."
    exit 1
fi

# Ejecutar backup
echo "Iniciando backup de '$ORIGEN'..."
echo "Destino: $RUTA_COMPLETA"

# Crear un archivo .tar.gz en ... comprimiendo el archivo que se encuentra en... (primero ingresa al directorio, luego indica el archivo/carpeta)
tar -czf "$RUTA_COMPLETA" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")"

#Si el codigo de salida del ultimo comando ejecutado ($?), en este caso tar, es 0, osea que fue exitoso, sale del programa con exito. Muestra el archivo creado y su tamaño
if [[ $? -eq 0 ]]; then
    echo "Backup completado: $RUTA_COMPLETA"
    ls -lh "$RUTA_COMPLETA"
    exit 0
else
    echo "Error: falló la creación del backup."
    exit 1
fi

